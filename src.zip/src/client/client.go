package client

type Client struct {
	Name    string
	Sexe    string
	Shampoo bool
}
