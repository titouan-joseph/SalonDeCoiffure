package salon

type Salon struct {
	name                  string
	num_coiff             int
	Waiting_line_capacity int
}
