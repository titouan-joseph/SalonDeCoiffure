package main

import (
    "fmt"
    //"sync"
)

const top int = 1000000000
//Iterate a variable from x to y
//PFR
func countFromXToY(x int, y int, fb chan string){
    for cpt := x; cpt < y; cpt++{
        if (cpt%1000 == 0){
            fmt.Printf("%d\n", cpt)
        }

    }
    //PFR    
    fb <- "FINI"
}

func main(){
    //PFR
    var feedbackChannel chan string

    feedbackChannel = make(chan string, 10)
    fmt.Printf("Coucou\n")

    routnum := 0
    for mcpt:= 0; mcpt < top; mcpt+= 1000000{
        //PFR
        routnum ++
        go countFromXToY(mcpt, mcpt + 999999, feedbackChannel)
    }

    //countFromXToY(0, 1000000000)

    //PFR
    for rescpt := 0; rescpt < routnum; rescpt ++{
        <- feedbackChannel        
    }

}
