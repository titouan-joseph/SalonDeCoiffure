package main

import (
    "fmt"
    //"sync"
)

type countRange struct{
    from int
    to int
}

const top int = 1000000000

//Iterate a variable from x to y
//PFR
func countFromXToY(inp chan countRange, fb chan string){
    for{   
        rng := <- inp 
        for cpt := rng.from; cpt < rng.to; cpt++{
            if (cpt%1000 == 0){
                fmt.Printf("%d\n", cpt)
            }

        }
        //PFR    
        fb <- "FINI"
    }
}

func main(){
    //PFR
    var inputChannel chan countRange
    var feedbackChannel chan string

    inputChannel = make (chan countRange, 10)
    feedbackChannel = make(chan string, 10)

    fmt.Printf("Coucou\n")

    routnum := 0
    for mcpt:= 0; mcpt < top; mcpt+= 1000000{
        routnum ++
        toPush := countRange{from: mcpt, to: mcpt+999999}
        inputChannel <- toPush
    }
    
    fmt.Printf("All Pushed\n")

    for channum := 0; channum < 10; channum++{
        go countFromXToY(inputChannel, feedbackChannel)
    } 
 
    //countFromXToY(0, 1000000000)

    //PFR
    for rescpt := 0; rescpt < routnum; rescpt ++{
        <- feedbackChannel        
    }

}
