package main

import (
    "fmt"
)

type countRange struct{
    from int
    to int
}


const top int = 1000000000
//Iterate a variable from x to y
//PFR

func countFromXToY(inp chan countRange, fb chan string){
    for{   
        rng := <- inp 
        fmt.Printf("IN %d\n", rng.from)
        for cpt := rng.from; cpt < rng.to; cpt++{
            if (cpt%1000 == 0){
                fmt.Printf("%d\n", cpt)
            }

        }
        //PFR    
        fb <- "FINI"
    }
}

func feedInput(inp chan countRange){
    for mcpt:= 0; mcpt < top; mcpt+= 1000000{
        toPush := countRange{from: mcpt, to: mcpt+999999}
        inp<- toPush
    }
    fmt.Printf("All Pushed\n")
}
func main(){
    //PFR
    var inputChannel chan countRange
    var feedbackChannel chan string

    inputChannel = make (chan countRange, 10)
    feedbackChannel = make(chan string, 10)

    fmt.Printf("Coucou\n")

    for channum := 0; channum < 10; channum++{
        go countFromXToY(inputChannel, feedbackChannel)
    } 
 
    go feedInput(inputChannel) 

    //countFromXToY(0, 1000000000)

    //PFR
    pushnum := top/1000000
    for rescpt := 0; rescpt < pushnum; rescpt ++{
        fmt.Printf("Run %d\n", rescpt)
        <- feedbackChannel        
    }

}
