package main

import (
    "fmt"
)

const top = 1000000000

//Iterate a variable from x to y
func countFromXToY(x int, y int){
    for cpt := x; cpt < y; cpt++{
        if (cpt%1000 == 0){
            fmt.Printf("%d\n", cpt)
        }

    }    

}

func main(){
    fmt.Printf("Coucou\n")
    countFromXToY(0, top)



}
