package main

import (
    "fmt"
    "sync"
)

const top = 1000000000

var wg sync.WaitGroup

//Iterate a variable from x to y
func countFromXToY(x int, y int){
    for cpt := x; cpt < y; cpt++{
        if (cpt%1000 == 0){
            fmt.Printf("%d\n", cpt)
        }

    }    
    wg.Done()

}

func main(){
    fmt.Printf("Coucou\n")

    for mcpt:= 0; mcpt < top ; mcpt+= 1000000{
        wg.Add(1)
        go countFromXToY(mcpt, mcpt + 999999)
    }

    //countFromXToY(0, 1000000000)

    wg.Wait()


}
